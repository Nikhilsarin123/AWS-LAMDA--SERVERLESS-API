'use strict';

const mongoose = require('mongoose');
const dbconnect = 'mongodb+srv://admin:g1u9npVYDylcuu0d@cluster0.ykbuy.mongodb.net/<tinderdb>?retryWrites=true&w=majority'


module.exports.hello = async(event) => {
const mongoose = require('mongoose');
mongoose.connect(dbconnect,{useNewUrlParser: true);

const Cat = mongoose.model('Cat', { name: String });

const kitty = new Cat({ name: 'Zildjian' });
await kitty.save();
  return{
    statusCode:200,
    body:JSON.stringify({
      message: 'Go serverless .your function executed succedfully',
      input: kitty,
    },
    null, 
    2),
  };

};